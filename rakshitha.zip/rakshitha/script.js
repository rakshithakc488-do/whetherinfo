const weatherCard = document.querySelector('.weather-card'); 
const locationElement = document.getElementById('location');
const temperatureElement = document.getElementById('temperature');
const conditionElement = document.getElementById('condition'); 
const refreshButton = document.getElementById('refresh-button'); 

const weatherData = [ 
  { location: 'Mysore', temperature: 22, condition: 'Sunny' },
  { location: 'Mandya', temperature: 18, condition: 'Cloudy' },
  { location: 'Hassan', temperature: 10, condition: 'Rainy' },
  { location: 'Bangalore', temperature: 32, condition: 'Sunny' },
  { location: 'Shivamogga', temperature: 20, condition: 'Cloudy' }
];

let currentWeatherIndex = 0;

function updateWeather() {
  const currentWeather = weatherData[currentWeatherIndex];

  
  locationElement.textContent = currentWeather.location;
  temperatureElement.textContent = `${currentWeather.temperature} °C`;
  conditionElement.textContent = currentWeather.condition;

  
  weatherCard.classList.remove('sunny', 'cloudy', 'rainy');

  switch (currentWeather.condition.toLowerCase()) {
    case 'sunny':
      weatherCard.classList.add('sunny');
      break;
    case 'rainy':
      weatherCard.classList.add('rainy');
      break;
    case 'cloudy':
      weatherCard.classList.add('cloudy');
      break;
  }

  
  currentWeatherIndex = (currentWeatherIndex + 1) % weatherData.length;
}


refreshButton.addEventListener('click', updateWeather);


updateWeather();
